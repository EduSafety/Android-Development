package com.dicoding.edusafety.data.model

data class MyItem(
    val imageResource: Int,
    val title: String,
    val description: String
)
